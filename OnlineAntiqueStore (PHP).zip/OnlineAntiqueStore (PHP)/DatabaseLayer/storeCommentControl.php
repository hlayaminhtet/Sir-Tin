<?php
	require_once("../DatabaseLayer/db.php");

	//session_start();
	if(isset($_POST["btnAddComment"])){

		$comment = $_POST["txtcomment"];
		$ProductID=$_GET['productID'];
		$user_sID =$_SESSION["user_ID"];
				

		$addComment_sql = "INSERT INTO `tbl_comment` (comment, comment_time, productID, userID) VALUES ('$comment', NOW(), '$ProductID', '$user_sID')";

		$addComment_query = mysql_query($addComment_sql);

			if($addComment_query){				
				echo '<script type="text/javascript">
					alert("Now, your comment is successful!!");
				  	</script>';

				$id= $_POST["txtpid"];
				header("location:product_details.php?productID=$id");
			}
			else{
				echo '<script type="text/javascript">
					alert("Your comment is fail!!");
				  	</script>';
			}

			
	}
  ?>