<?php
	require_once("../DatabaseLayer/db.php");

	//session_start();
	if(isset($_POST["btnSendMessage"])){

		$user_sID =$_SESSION["user_ID"];
		$username =$_POST['username'];
		$sourceEmail=$_POST['user_email'];
	  	$destinationEmail=$_POST['destination_email'];
		$userphone=$_POST['user_phone_number'];
		$message=$_POST['message'];
		
		// $destination_id="";
		if($user_sID=="A-00001"){

		$sendMessage_sql = "INSERT INTO `tbl_notification`(`noti_userID`, `noti_username`, `noti_email`, `destination_email`, `noti_phone_number`, `noti_message`, `noti_status`, `noti_date`) VALUES ('$user_sID','$username', '$sourceEmail', '$destinationEmail', '$userphone', '$message', 'unread', NOW() )";

		$sendMessage_query = mysql_query($sendMessage_sql);

		
			if($sendMessage_query){	
				$update_destination_id_sql ="UPDATE tbl_notification n INNER JOIN tbl_user u ON n.destination_email=u.user_email SET n.destination_id=u.user_ID";
				$update_destination_id_query=mysql_query($update_destination_id_sql);
			
				if($update_destination_id_query){
					echo '<script type="text/javascript">
					alert("Now, your message is successful!!");
					window.location.href="contact.php";
				  	</script>';
				 }
			}
			else{
				echo '<script type="text/javascript">
					alert("Your message is fail!!");
				  	</script>';
			}
		}
		else{
			$sendMessage_sql = "INSERT INTO `tbl_notification`(`noti_userID`, `noti_username`, `noti_email`, `destination_email`, `noti_phone_number`, `noti_message`, `noti_status`, `noti_date`) VALUES ('$user_sID','$username', '$sourceEmail', 'admin.antigua@gmail.com', '$userphone', '$message', 'unread', NOW() )";

			$sendMessage_query = mysql_query($sendMessage_sql);

		
			if($sendMessage_query){	
				$update_destination_id_sql ="UPDATE tbl_notification n INNER JOIN tbl_user u ON n.destination_email=u.user_email SET n.destination_id=u.user_ID";
				$update_destination_id_query=mysql_query($update_destination_id_sql);
			
				if($update_destination_id_query){
					echo '<script type="text/javascript">
					alert("Now, your message is successful!!");
					window.location.href="contact.php";
				  	</script>';
				 }
			}
			else{
				echo '<script type="text/javascript">
					alert("Your message is fail!!");
				  	</script>';
			}
		}

			
	}
  ?>