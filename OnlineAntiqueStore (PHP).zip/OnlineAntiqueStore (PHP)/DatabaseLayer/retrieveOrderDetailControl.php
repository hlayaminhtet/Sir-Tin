<?php  
	//for retrieving info of order detail  by admin
	$orderID=$_GET['order_ID'];

    $order_detail_sql="SELECT * FROM tbl_order o INNER JOIN tbl_order_detail od ON o.order_id=od.order_id and o.order_id='$orderID' order by o.order_id asc";
    $order_detail_query=mysql_query($order_detail_sql);
    $order_detail_count = mysql_num_rows($order_detail_query);
    $order_detail_row = mysql_fetch_array($order_detail_query);

    $order_detail_sql1="SELECT * FROM tbl_order_detail od where order_id='$orderID'";
    $order_detail_query1=mysql_query($order_detail_sql1);
    $order_detail_count1 = mysql_num_rows($order_detail_query1);
?>