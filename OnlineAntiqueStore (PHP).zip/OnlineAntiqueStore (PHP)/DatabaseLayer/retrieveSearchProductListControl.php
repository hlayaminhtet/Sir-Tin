<?php
	if (isset($_POST['btnsearch']))
	{
		$SearchItem=$_POST["txtsearch"];
		$searchItem_sql="SELECT * FROM `tbl_product` WHERE product_category LIKE '$SearchItem%' or product_name LIKE '$SearchItem%'";
		$searchItem_query=mysql_query($searchItem_sql);
	 	$searchItem_count= mysql_num_rows($searchItem_query);
	}
?>