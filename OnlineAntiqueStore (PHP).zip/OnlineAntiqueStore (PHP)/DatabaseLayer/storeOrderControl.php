<?php 	
session_start();
	// if (!isset($_SESSION['ShoppingCart'])) {
	// 	echo '<script type="text/javascript">
	// 			alert("Your shopping cart is emty!!");
	// 			</script>';
		// }

	require_once("../DatabaseLayer/db.php");
	//for retrieving info of order's id
    require_once("../BusinessLayer/AutoID.php");

    //for retrieving shopping cart information
    require_once("../BusinessLayer/ShoppingCart.php");

	if(isset($_POST["btnOrder"])){
		//$contact_name=$_POST["txtcontactname"];
		$contact_ph=$_POST["txtcontactph"];
		$delivery_address=$_POST["txtdeliaddress"];
		$delivery_country=$_POST["txtdelicountry"];
		$delivery_charge=$_POST["txtdelicharge"];
		$order_id =$_POST["txtorderid"];
		$order_date=$_POST["txtorderdate"];
		$customer_id=$_SESSION['user_ID'];
		$customer_name=$_POST["txtcusname"];
		$total_amount=$_POST["txttotalamt"];
		$payment_type=$_POST["txtpaytype"];
		$acc_name=$_POST["txtaccname"];
		$acc_number=$_POST["txtaccno"];
		
		$accnumberlength=strlen($acc_number);

		if($accnumberlength != 19){
				echo '<script type="text/javascript">
            	alert("Bank account number must be 16 digits. for example: xxxx-xxxx-xxxx-xxxx");
            	window.history.back();
			  	</script>';
		}

		else
		{

			$order_sql="INSERT INTO `tbl_order`(`order_id`,`order_date`, `customer_id`, `customer_name`, `total_amt`, `contact_ph`, `delivery_address`, `delivery_country`, `delivery_charges`, `payment_type`, `bank_acc_number`, `bank_acc_name`)VALUES('$order_id','$order_date', '$customer_id', '$customer_name', '$total_amount', '$contact_ph', '$delivery_address', '$delivery_country', '$delivery_charge','$payment_type','$acc_number', '$acc_name')";


			$order_query=mysql_query($order_sql);
			
			$size=count($_SESSION['ShoppingCart']);

			for($i = 0; $i < $size; $i++){
				$product_code=$_SESSION['ShoppingCart'][$i]['ProductCode'];
				$product_name = $_SESSION['ShoppingCart'][$i]['ProductName'];
				$product_No_of_Qty=$_SESSION['ShoppingCart'][$i]['ProductNoOfQty'];
				$product_price =$_SESSION['ShoppingCart'][$i]['ProductPrice'];
				$product_amount=$_SESSION['ShoppingCart'][$i]['ProductNoOfQty'] * $_SESSION['ShoppingCart'][$i]['ProductPrice'];
				
				echo $orderdetail_sql ="INSERT INTO `tbl_order_detail`(`order_id`, `product_code`, `product_name`, `product_price`, `product_qty`, `product_amount`) VALUES ('$order_id', '$product_code', '$product_name','$product_price',  '$product_No_of_Qty', '$product_amount')";
				$orderdetail_query= mysql_query($orderdetail_sql);


				$update_produtct="UPDATE tbl_product
									set number_of_copy=number_of_copy-'$product_No_of_Qty'
									where product_code='$product_code'";
				$update_product_query=mysql_query($update_produtct);					


			}

			if($orderdetail_query){
				echo Clear();
				echo '<script type="text/javascript">
	            	alert("Now, your order  is successful!!");
					window.location.href="../PresentationLayer/index.php";
				  	</script>';
			}
			else{
	            	echo '<script type="text/javascript">
	            	alert("Now, your order  is fail!!");
				  	</script>';
	            }
			}		
	}
?>