<?php  
	session_start();
	session_destroy();

	$_SESSION["user_ID"]=null;

	echo '<script type="text/javascript">
			window.location.href="../PresentationLayer/login.php";
		  </script>';

?>