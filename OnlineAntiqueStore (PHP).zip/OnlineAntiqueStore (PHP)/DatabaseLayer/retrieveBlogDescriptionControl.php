<?php
	$blog_des_id= $_GET['blogID'];

	//for retrieving blog description
    $blog_des_sql="SELECT * FROM `tbl_blog` where blog_id='$blog_des_id'";
    $blog_des_query=mysql_query($blog_des_sql);
    $blog_des_count = mysql_num_rows($blog_des_query);
    $blog_des_row=mysql_fetch_array($blog_des_query);
?>
