<?php  
	session_start();
	$user_sID =$_SESSION["user_ID"];
	$user_sql = "SELECT * FROM tbl_user where user_ID='$user_sID'";
	$user_query = mysql_query($user_sql);
	$user_count = mysql_num_rows($user_query);
	$user_row=mysql_fetch_array($user_query);
?>