<?php
	$delivery_country_sql = "SELECT * FROM `tbl_delivery`";
	$delivery_country_query = mysql_query($delivery_country_sql);
	$delivery_country_count = mysql_num_rows($delivery_country_query);
?>