<?php  
	//for retrieving info of order by admin
    $order_sql="SELECT * FROM `tbl_order`";
    $order_query=mysql_query($order_sql);
    $order_count = mysql_num_rows($order_query);
?>

