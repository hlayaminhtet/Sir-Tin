<?php
	require_once("db.php");

	if(isset($_POST["btnDeleteMsg"])){
		$deleteNotiID= $_GET['noti_ID'];

		$deleteNotiMsg_sql = "DELETE FROM `tbl_notification` WHERE `noti_id`='$deleteNotiID'";
		$deleteNotiMsg_query = mysql_query($deleteNotiMsg_sql);

			if($deleteNotiMsg_query){
				if($_SESSION['user_ID']=='A-00001')
                {
					echo '<script type="text/javascript">
					alert("Now, deleting message is successful!!");
					window.location.href="admin_index.php";
				  	</script>';
				}
				else{
					echo '<script type="text/javascript">
					alert("Now, deleting message is successful!!");
					window.location.href="index.php";
				  	</script>';
				}
			}
			else{
				'<script type="text/javascript">
				alert("Now, deleting information of the product is fail!!");
			  	</script>';
			}
	}
?>