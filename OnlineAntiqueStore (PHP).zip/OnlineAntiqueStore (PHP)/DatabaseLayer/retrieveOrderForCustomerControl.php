<?php  
	//for retrieving info of order by customer
	$customer_id=$_SESSION['user_ID'];

    $customer_order_sql="SELECT * FROM tbl_order WHERE customer_id='$customer_id'";
    $customer_order_query=mysql_query($customer_order_sql);
    $customer_order_count = mysql_num_rows($customer_order_query);
    // $customer_order_row = mysql_fetch_array($customer_order_query);
?>

