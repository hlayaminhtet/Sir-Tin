<?php 
	//for retrieving info of Product Category
    $product_category_sql="SELECT `product_category_name` FROM `tbl_product_category`";
    $product_category_query=mysql_query($product_category_sql);
    $product_category_count = mysql_num_rows($product_category_query);
 ?>