<?php
	require_once("db.php");

	if(isset($_POST["btnUpdateUserInfo"])){
		
		$user_sID =$_SESSION["user_ID"];
		$ufname = $_POST["txtuserfname"];
		$ulname = $_POST["txtuserlname"];
		$uemail = $_POST["txtuseremail"];
		$upassword = $_POST["txtuserpwd"];
		$ubday =  $_POST["txtuserbday"];
		$uaddress = $_POST["txtuseraddress"];
		$ucountry = $_POST["txtusercountry"];
		$uph = $_POST["txtuserph"];
		$passwordlength=strlen($upassword);
		
		if(!filter_var($uemail, FILTER_VALIDATE_EMAIL)) {
  			echo '<script type="text/javascript">
					alert("Invalid email address format.");
					window.history.back();
				  </script>';
		}
		elseif($passwordlength < 6){
			echo '<script type="text/javascript">
					alert("Invalid password. Password must be at least 6 characters.");
					window.history.back();
				  </script>';
		}
		elseif($passwordlength > 15){
			echo '<script type="text/javascript">
					alert("Invalid password. Password cannot be greater than 15.");
					window.history.back();
				  </script>';
		}
		else{
			$updateUserInfo_sql = "UPDATE `tbl_user` SET `user_firstname`='$ufname', `user_lastname`='$ulname', `user_email`='$uemail', `user_password`='$upassword', `user_birthday`='$ubday', `user_address`='$uaddress', `user_country`='$ucountry', `user_phone_number`='$uph' WHERE `user_ID`='$user_sID'";

			$updateUserInfo_query = mysql_query($updateUserInfo_sql);

				if($updateUserInfo_query){
					echo '<script type="text/javascript">
						alert("Now, your update process is successful!!");
							window.location.href="profile.php";
					  	</script>';
				}
				else{
					echo '<script type="text/javascript">
						alert("Your update proccess is fail!!");
					  	</script>';
				}
		}
	}
  ?>