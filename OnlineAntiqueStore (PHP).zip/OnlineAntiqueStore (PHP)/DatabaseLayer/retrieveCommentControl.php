<?php  
	// if(isset($_GET['productID']))
	// {


		$ProductID=$_GET['productID'];

		$comment_sql = "SELECT * FROM tbl_comment c, tbl_user u WHERE c.userID=u.user_ID AND c.productID='$ProductID' ORDER BY comment_time ASC";

		//"SELECT user_firstname, user_lastname, comment FROM tbl_comment c, tbl_user u WHERE c.userID=u.user_ID";
		$comment_query = mysql_query($comment_sql);
		$comment_count = mysql_num_rows($comment_query);
		//$comment_row=mysql_fetch_array($comment_query);
		//}
?>