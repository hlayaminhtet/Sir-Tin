<?php 
	require_once("db.php");

	if(isset($_POST["btnAddProduct"])){

	$productCode=$_POST["txtproductcode"];
	$productName=$_POST["txtproductname"];
	$productCategory=$_POST["txtproductcategory"];
	$productCountryOrigin=$_POST["txtproductcountryorigin"];
	$productPlaceOrigin=$_POST["txtproductplaceoforigin"];
	$productLifeSpan=$_POST["txtproductlifespan"];
	$productColor=$_POST["txtproductcolor"];
	$productCharacteristics=$_POST["txtproductcharacteristics"];
	$productNoOfCopy=$_POST["txtproductnoofcopy"];
	$productDescription=$_POST["txtproductdescription"];
	$productPrice=$_POST["txtproductprice"];
	
	$productImage = $_FILES['txtproductimage']['name'];
	$productFolder = "../PresentationLayer/product_image/";

	if($productImage){
		$productFileName = $productFolder . $productCode . "_" .$productImage;
		$copied =copy($_FILES['txtproductimage']['tmp_name'], $productFileName);

		if(!$copied){
			exit("Problem occured. Cannot Upload Product Image.");
		}
	}

	$productInfo_sql = "SELECT * FROM tbl_product where product_code = '$productCode'";
	$productInfo_query = mysql_query($productInfo_sql);
	$productInfo_count = mysql_num_rows($productInfo_query);

	if($productInfo_count > 0){
		echo '<script type="text/javascript">
				alert("This name is already exist. Try with another Product Name.");
			  </script>';
	}

	else{
	$productInfo_sql1 = "INSERT INTO `tbl_product`(`product_code`, `product_name`, `product_image`, `product_category`, `product_country_origin`, `product_place_of_origin`, `product_lifespan`, `product_color`, `product_characteristics`, `number_of_copy`, `product_description`, `product_price`) VALUES ('$productCode', '$productName', '$productFileName', '$productCategory', '$productCountryOrigin', '$productPlaceOrigin', '$productLifeSpan', '$productColor', '$productCharacteristics', '$productNoOfCopy', '$productDescription', '$productPrice')";

	$productInfo_query1 = mysql_query($productInfo_sql1);

		if($productInfo_query1){
			echo '<script type="text/javascript">
				alert("Now, adding product information is successful!!");
				window.location.href="manage_product.php";
			  	</script>';
		}
		else{
			echo '<script type="text/javascript">
				alert("Now, adding product information is fail!!");
			  	</script>';
		}
	}
}
?>