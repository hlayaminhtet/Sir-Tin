<?php
	$product_category=$_GET['ProductCategory'];

    $product_categorylist_sql="SELECT `product_id`,`product_category`, `product_name`, `product_image`, `product_price` FROM tbl_product WHERE product_category='$product_category'";
    $product_categorylist_query=mysql_query($product_categorylist_sql);
    $product_categorylist_count = mysql_num_rows($product_categorylist_query);
?>