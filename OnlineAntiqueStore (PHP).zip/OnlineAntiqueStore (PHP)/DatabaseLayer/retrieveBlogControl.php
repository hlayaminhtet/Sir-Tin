<?php  
	//for retrieving blog
    $blog_sql="SELECT * FROM `tbl_blog` ORDER BY blog_date DESC";
    $blog_query=mysql_query($blog_sql);
    $blog_count = mysql_num_rows($blog_query);
?>

