<?php
	//session_start();

	require_once("db.php");
	require_once("../BusinessLayer/ShoppingCart.php");

	if(isset($_POST['action']))
	{
		if(isset($_POST['action'])=="reserve"){
			//echo $ProductCode = $_GET['ProductCode'];
			//$ProductCode = $_POST['txtProductCode'];
			$ProductCode = $_POST['txtproductcode'];
			$ProductName = $_POST['txtproductname'];
			//$ProductImage = $_POST['productimage'];
			$ProductCategory = $_POST['txtproductcategory'];
			$ProductPrice = $_POST['txtproductprice'];
			$ProductNoOfQty = $_POST['txtproductNoOfQty'];
			$cTotal = $ProductPrice * $ProductNoOfQty;

			$sql= "SELECT * FROM tbl_product where product_code='$ProductCode'";
		    $query =mysql_query($sql);
		    $count = mysql_num_rows($query);
		    $row_product=mysql_fetch_array($query);
		    $CurrentQty=$row_product['number_of_copy'];


			if($ProductNoOfQty <= 0)
			{
				echo '<script type="text/javascript">
						alert("Invalid Quantity");
					  </script>';
			}

			elseif($ProductNoOfQty > $CurrentQty)
			{
				echo '<script type="text/javascript">
						alert("Insufficient Quantity");
					  </script>';
			}
			
			else
			{
				//echo "$ProductCode";
				$statusOK =  Insert($ProductCode, $ProductNoOfQty);
			}
		}
	}
	if(isset($_GET['action']))
	{
		if($_GET['action']=="remove"){
			$ProductCode=$_GET['ProductCode'];
			Remove($ProductCode);
		}
		elseif($_GET['action']=="ClearReservation")
		{
			Clear();
			echo '<script type="text/javascript">
					alert("You cleared all reservation.");
					window.location.href = "index.php";
				  </script>';
		}
	}
?>