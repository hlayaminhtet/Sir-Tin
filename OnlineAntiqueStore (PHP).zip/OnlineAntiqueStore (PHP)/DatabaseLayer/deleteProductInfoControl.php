<?php
	require_once("db.php");

	if(isset($_POST["btnDeleteProduct"])){
		$deleteCodeName= $_POST["txtdeletecodename"];

		$deleteproductInfo_sql = "DELETE FROM `tbl_product` WHERE `product_code`='$deleteCodeName' OR `product_name`='$deleteCodeName'";
			$deleteproductInfo_query = mysql_query($deleteproductInfo_sql);

			if($deleteproductInfo_query){
				echo '<script type="text/javascript">
				alert("Now, deleting information of the product is successful!!");
				window.location.href="manage_product.php";
			  	</script>';
			}
			else{
				'<script type="text/javascript">
				alert("Now, deleting information of the product is fail!!");
			  	</script>';
			}
	}
?>