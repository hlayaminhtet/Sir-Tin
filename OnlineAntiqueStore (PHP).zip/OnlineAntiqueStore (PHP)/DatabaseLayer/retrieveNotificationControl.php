<?php  
	//for retrieving noti
	
	$user_sID =$_SESSION["user_ID"];
    $noti_sql="SELECT * FROM `tbl_notification` n, tbl_user u WHERE n.noti_status='unread' AND n.destination_id='$user_sID' AND n.destination_id=u.user_ID";
    $noti_query=mysql_query($noti_sql);
    $noti_count = mysql_num_rows($noti_query);

	$noti_sql1="SELECT * FROM `tbl_notification` n, tbl_user u WHERE n.destination_id='$user_sID' AND n.destination_id=u.user_ID ORDER BY n.noti_id DESC LIMIT 4";
    $noti_query1=mysql_query($noti_sql1);
    $noti_count1 = mysql_num_rows($noti_query1);
?>

