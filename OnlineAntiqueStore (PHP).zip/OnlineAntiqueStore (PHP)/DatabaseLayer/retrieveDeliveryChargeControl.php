<?php  
	//session_start();

		//$delivery_country=$_SESSION['user_country'];
		$user_sID=$_SESSION['user_ID'];

			$delivery_charge_sql = "SELECT d.delivery_charges FROM tbl_user u INNER JOIN tbl_delivery d ON u.user_country=d.delivery_country WHERE u.user_ID='$user_sID'";
			$delivery_charge_query = mysql_query($delivery_charge_sql);
			$delivery_charge_count = mysql_num_rows($delivery_charge_query);
			$delivery_charge_row=mysql_fetch_array($delivery_charge_query);

			// $delivery_charge=$delivery_charge_row['delivery_charges'];

		//$_POST['txtdelicharge']=$delivery_charge_row["delivery_charges"];
?>