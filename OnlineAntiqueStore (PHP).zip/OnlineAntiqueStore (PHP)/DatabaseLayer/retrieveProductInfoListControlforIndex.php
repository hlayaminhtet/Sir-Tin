<?php  
	//for retrieving info of Product
    $product_sql="SELECT * FROM tbl_product ORDER BY product_category LIMIT 5, 6";
    $product_query=mysql_query($product_sql);
    $product_count = mysql_num_rows($product_query);
?>

