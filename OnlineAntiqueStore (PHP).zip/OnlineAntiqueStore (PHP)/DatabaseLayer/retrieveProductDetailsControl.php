<?php
	$ProductID=$_GET['productID'];

    $product_detail_sql="SELECT * FROM tbl_product WHERE product_id='$ProductID'";
    $product_detail_query=mysql_query($product_detail_sql);
    $product_detail_count = mysql_num_rows($product_detail_query);
?>