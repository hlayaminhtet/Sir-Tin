<?php  
	//for retrieving info of Product
    $product_sql="SELECT * FROM `tbl_product`";
    $product_query=mysql_query($product_sql);
    $product_count = mysql_num_rows($product_query);
?>

