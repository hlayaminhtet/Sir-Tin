<?php 
	require_once("db.php");

	if(isset($_POST["btnEditProduct"])){

		//$productID=$_POST["txtproductid"];
		$productCode=$_POST["txtproductcode"];
		$productName=$_POST["txtproductname"];
		$productCategory=$_POST["txtproductcategory"];
		$productCountryOrigin=$_POST["txtproductcountryorigin"];
		$productPlaceOrigin=$_POST["txtproductplaceoforigin"];
		$productLifeSpan=$_POST["txtproductlifespan"];
		$productColor=$_POST["txtproductcolor"];
		$productCharacteristics=$_POST["txtproductcharacteristics"];
		$productNoOfCopy=$_POST["txtproductnoofcopy"];
		$productDescription=$_POST["txtproductdescription"];
		$productPrice=$_POST["txtproductprice"];

		$productImage = $_FILES['txtproductimage']['name'];
		$productFolder = "../PresentationLayer/product_image/";

		if($productImage){

			$productFileName = $productFolder . $productCode . "_" .$productImage;
			$copied =copy($_FILES['txtproductimage']['tmp_name'], $productFileName);

			if(!$copied){
				exit("Problem occured. Cannot Upload Product Image.");
			}
			$editProductInfo_sql = "UPDATE `tbl_product` SET `product_name`='$productName', `product_image`='$productFileName', `product_category`='$productCategory', `product_country_origin`='$productCountryOrigin', `product_place_of_origin`='$productPlaceOrigin', `product_lifespan`='$productLifeSpan', `product_color`='$productColor', `product_characteristics`='$productCharacteristics', `number_of_copy`='$productNoOfCopy', `product_description`='$productDescription', `product_price`='$productPrice' WHERE `product_code`='$productCode'";	

		$editProductInfo_query =mysql_query($editProductInfo_sql);
		if($editProductInfo_query){
			echo '<script type="text/javascript">
				alert("Now, your update process is successful!!");					
			  	</script>';
		}
		else{
			echo '<script type="text/javascript">
				alert("Your update proccess is fail!!");
			  	</script>';
		}
		}
		else{
			$editProductInfo_sql1 = "UPDATE `tbl_product` SET `product_name`='$productName',  `product_category`='$productCategory', `product_country_origin`='$productCountryOrigin', `product_place_of_origin`='$productPlaceOrigin', `product_lifespan`='$productLifeSpan', `product_color`='$productColor', `product_characteristics`='$productCharacteristics', `number_of_copy`='$productNoOfCopy', `product_description`='$productDescription', `product_price`='$productPrice' WHERE `product_code`='$productCode'";	

		$editProductInfo_query1 =mysql_query($editProductInfo_sql1);
		
		if($editProductInfo_query1){
			echo '<script type="text/javascript">
				alert("Now, your update process is successful!!");
			  	</script>';
		}
		else{
			echo '<script type="text/javascript">
				alert("Your update proccess is fail!!");
			  	</script>';
		}
	}
}
?>