<?php  
	//for retrieving info of Product in update value
	
	$productID=$_GET['product_ID'];
	
    $edit_product_sql="SELECT * FROM `tbl_product` where product_id='$productID'";
    $edit_product_query=mysql_query($edit_product_sql);
    $edit_product_count = mysql_num_rows($edit_product_query);
    $edit_product_row=mysql_fetch_array($edit_product_query);
?>

