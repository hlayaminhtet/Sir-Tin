<?php
	require_once("db.php");

	//session_start();
	if(isset($_POST["btnBlogging"])){
	
		$blogTitle=$_POST["txtblogtitle"];
		$blogDesc=$_POST["txtblogdescription"];
		//$blogImage=$_POST["txtblogimage"];

		$blogImage = $_FILES['txtblogimage']['name'];
		$blogFolder = "../PresentationLayer/product_image/";

		if($blogImage){
			$blogFileName = $blogFolder . $blogImage;
			$copied =copy($_FILES['txtblogimage']['tmp_name'], $blogFileName);

			if(!$copied){
				exit("Problem occured. Cannot Upload Product Image.");
		}
	}

		$blog_sql = "INSERT INTO `tbl_blog`(`blog_image`, `blog_name`, `blog_description`, `blog_date`) VALUES ('$blogFileName', '$blogTitle', '$blogDesc', NOW())";

		$blog_query = mysql_query($blog_sql);

			if($blog_query){
				echo '<script type="text/javascript">
					alert("Now, blogging is successful!!");
					window.location.href="manage_product.php";
				  	</script>';
			}
			else{
				echo '<script type="text/javascript">
					alert("Blogging is fail!!");
				  	</script>';
			}
}
?>