<?php 
	require_once("../DatabaseLayer/db.php");

	if(isset($_POST["btnSignup"]))
	{
		$uid = $_POST["txtuserid"];
		$ufname = $_POST["txtuserfname"];
		$ulname = $_POST["txtuserlname"];
		$uemail = $_POST["txtuseremail"];
		$upassword = $_POST["txtuserpwd"];
		$ubday =  $_POST["txtuserbday"];
		$ugender =  $_POST["rdousergender"];
		$uaddress = $_POST["txtuseraddress"];
		$ucountry = $_POST["txtusercountry"];
		$uph = $_POST["txtuserph"];
		$passwordlength=strlen($upassword);

		if($passwordlength < 6){
			echo '<script type="text/javascript">
					alert("Invalid password. Password must be at least 6 characters.");
					window.history.back();
				  </script>';
		}
		elseif($passwordlength > 15){
			echo '<script type="text/javascript">
					alert("Invalid password. Password cannot be greater than 15.");
					window.history.back();
				  </script>';
		}

		elseif($ugender==null){
			echo '<script type="text/javascript">
					alert("Please choose one in Gender!!");
					window.history.back();
				  </script>';
		}
		elseif($ucountry=="Country:"){
			echo '<script type="text/javascript">
					alert("Please choose one in Country!!");
					window.history.back();
				  </script>';
		}

		elseif(!filter_var($uemail, FILTER_VALIDATE_EMAIL)) {
  			echo '<script type="text/javascript">
					alert("Invalid email address format.");
					window.history.back();
				  </script>';
		}
		else{

			$user_query = "SELECT * FROM tbl_user where user_id = '$uid'";
			$user_ret = mysql_query($user_query);
			$user_num_row = mysql_num_rows($user_ret);

			if($user_num_row > 0){
				echo '<script type="text/javascript">
						alert("This name is already exist. Try with another User Name.");
					  </script>';
			}

			else{
			$user_sql = "INSERT INTO `tbl_user` VALUES ('$uid','$ufname', '$ulname', '$uemail', '$upassword', '$ubday', '$ugender','$uaddress', '$ucountry', '$uph', 'user', CURRENT_DATE)";

			$user_result = mysql_query($user_sql);

				if($user_result){
					echo '<script type="text/javascript">
						alert("Now, your registration is successful!!");
						window.location.href="login.php";
					  	</script>';
				}
				else{
					echo '<script type="text/javascript">
						alert("Now, your registration is fail!!");
						window.location.href="login.php";
					  	</script>';
				}
			}
		}
	}
 ?>