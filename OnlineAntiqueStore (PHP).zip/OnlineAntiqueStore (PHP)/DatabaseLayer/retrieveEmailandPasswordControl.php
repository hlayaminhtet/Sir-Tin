<?php  
	session_start();

	if(isset($_POST["btnLogin"])){
		
		$email= $_POST["txtuseremail"];
		$password=$_POST["txtuserpwd"];

		if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  			echo '<script type="text/javascript">
					alert("Invalid email address format.");
					window.history.back();
				  </script>';
		}
		else{

			$sql="SELECT * FROM tbl_user where user_email = '$email' and user_password='$password'";
			$query =mysql_query($sql);
			$count= mysql_num_rows($query);
			$row =mysql_fetch_array($query);

			if($count > 0){

				if($row["user_ID"]=="A-00001")
				{
					$_SESSION["user_ID"]="A-00001";

					echo '<script type="text/javascript">
						alert("Login successfully.");
						window.location.href="admin_index.php";
					</script>';
				}
				else{
					$cid= $row["user_ID"];
					$_SESSION["user_ID"]=$cid;

					echo '<script type="text/javascript">
					alert("Login successfully.");
					window.location.href="index.php";
					</script>';

				}
			}
			else{
				echo '<script type="text/javascript">
					alert("Fail login.");
					window.location.href="login.php";
					</script>';
			}
		}
	}
?>