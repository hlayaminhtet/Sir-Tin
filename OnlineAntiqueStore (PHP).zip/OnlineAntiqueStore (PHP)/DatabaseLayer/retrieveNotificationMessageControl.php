<?php
	
	$noti_id=$_GET['noti_ID'];
	$updateStatus_sql = "UPDATE tbl_notification n INNER JOIN tbl_user u ON n.destination_email=u.user_email SET `noti_status`='read' WHERE n.noti_id='$noti_id'";
	$updateStatus_query = mysql_query($updateStatus_sql);

	$showMessage_sql= "SELECT * FROM tbl_notification n INNER JOIN tbl_user u ON n.destination_id=u.user_ID WHERE n.noti_id='$noti_id'";
	$showMessage_query=mysql_query($showMessage_sql);
	$showMessage_count=mysql_num_rows($showMessage_query);
	$showMessage_row=mysql_fetch_array($showMessage_query);
?>