<?php  
	//for editing info of Product
    $edit_product_sql="SELECT * FROM `tbl_product`";
    $edit_product_query=mysql_query($edit_product_sql);
    $edit_product_count = mysql_num_rows($edit_product_query);
?>

