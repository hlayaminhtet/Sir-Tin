-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2019 at 06:39 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbantiquestore`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog`
--

CREATE TABLE `tbl_blog` (
  `blog_id` int(11) NOT NULL,
  `blog_image` varchar(100) NOT NULL,
  `blog_name` varchar(50) DEFAULT NULL,
  `blog_description` varchar(700) DEFAULT NULL,
  `blog_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_blog`
--

INSERT INTO `tbl_blog` (`blog_id`, `blog_image`, `blog_name`, `blog_description`, `blog_date`) VALUES
(1, '../PresentationLayer/product_image/depression.jpg', 'The Great Depression ', 'The Great Depression was the worst economic downturn in the history of the industrialized world. It started in 1929 and ended in 1939. It started after the stock market crash of October 1929, which sent Wall Street into a panic and wiped out millions of investors. Over the next several years, consumer spending and investment dropped, causing steep declines in industrial output and employment as failing companies laid off workers. By 1933, when the Great Depression reached its lowest point, some 15 million Americans were unemployed and nearly half the country banks had failed.', '2019-09-07 00:00:00'),
(2, '../PresentationLayer/product_image/Aung San Su Kyi.jpg', 'Aung San Su Kyi', 'Aung San Suu Kyi, also called Daw Aung San Suu Kyi, (born June 19, 1945, Rangoon, Burma [now Yangon, Myanmar]), politician and opposition leader of Myanmar, daughter of Aung San (a martyred national hero of independent Burma) and Khin Kyi (a prominent Burmese diplomat), and winner of the Nobel Prize for Peace in 1991. She held multiple governmental posts since 2016, including that of state counselor, which essentially made her the de facto leader of the country.', '2019-09-07 01:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment`
--

CREATE TABLE `tbl_comment` (
  `comment_id` int(11) NOT NULL,
  `comment` varchar(600) DEFAULT NULL,
  `comment_time` datetime DEFAULT NULL,
  `productID` int(11) DEFAULT NULL,
  `userID` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_comment`
--

INSERT INTO `tbl_comment` (`comment_id`, `comment`, `comment_time`, `productID`, `userID`) VALUES
(1, 'I think this pottery is good.', '2019-10-04 22:47:53', 24, 'U-00001');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_delivery`
--

CREATE TABLE `tbl_delivery` (
  `delivery_id` int(11) NOT NULL,
  `delivery_country` varchar(20) NOT NULL,
  `delivery_charges` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_delivery`
--

INSERT INTO `tbl_delivery` (`delivery_id`, `delivery_country`, `delivery_charges`) VALUES
(1, 'America', 20),
(2, 'China', 350),
(3, 'England', 300),
(4, 'Thailand', 340),
(5, 'Myanmar', 340),
(6, 'Laos', 340),
(7, 'Indonesia', 320),
(8, 'Malaysia', 320),
(9, 'Philippines', 320),
(10, 'Cambodia', 330),
(11, 'India', 330),
(12, 'Bangladesh', 330),
(13, 'Singapore', 310),
(14, 'Vitanam', 340),
(15, 'Brunei', 330),
(16, 'Others', 360);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notification`
--

CREATE TABLE `tbl_notification` (
  `noti_id` int(11) NOT NULL,
  `noti_userID` varchar(11) NOT NULL,
  `noti_username` varchar(40) NOT NULL,
  `noti_email` varchar(40) NOT NULL,
  `destination_email` varchar(40) NOT NULL,
  `destination_id` varchar(20) NOT NULL,
  `noti_phone_number` varchar(25) NOT NULL,
  `noti_message` varchar(1000) NOT NULL,
  `noti_status` varchar(10) NOT NULL,
  `noti_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_notification`
--

INSERT INTO `tbl_notification` (`noti_id`, `noti_userID`, `noti_username`, `noti_email`, `destination_email`, `destination_id`, `noti_phone_number`, `noti_message`, `noti_status`, `noti_date`) VALUES
(1, 'A-00001', 'Hla Yamin Htet', 'admin.antigua@gmail.com', 'emma@gmail.com', 'U-00001', '424-272-0273', 'Thank you for your purchase.', 'unread', '2019-10-04 22:57:03');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` varchar(15) NOT NULL,
  `order_date` varchar(20) NOT NULL,
  `customer_id` varchar(15) NOT NULL,
  `customer_name` varchar(30) NOT NULL,
  `total_amt` int(11) NOT NULL,
  `contact_ph` varchar(20) NOT NULL,
  `delivery_address` varchar(200) NOT NULL,
  `delivery_country` varchar(20) NOT NULL,
  `delivery_charges` int(11) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `bank_acc_number` varchar(40) NOT NULL,
  `bank_acc_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `order_date`, `customer_id`, `customer_name`, `total_amt`, `contact_ph`, `delivery_address`, `delivery_country`, `delivery_charges`, `payment_type`, `bank_acc_number`, `bank_acc_name`) VALUES
('O-00001', '2019-10-04', 'U-00001', 'Emma Megan', 20000, '+44 20 7123 1234', 'No.21, Fairfield Street, London', 'England', 300, 'Visa', '1234-5678-9012-3456', 'Emma Megan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_detail`
--

CREATE TABLE `tbl_order_detail` (
  `order_id` varchar(15) NOT NULL,
  `product_code` varchar(10) NOT NULL,
  `product_name` varchar(40) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `product_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order_detail`
--

INSERT INTO `tbl_order_detail` (`order_id`, `product_code`, `product_name`, `product_price`, `product_qty`, `product_amount`) VALUES
('O-00001', 'P-00020', 'Ancient tables', 1700, 1, 1700),
('O-00001', 'P-00003', 'Chinese Porcelain ', 9000, 2, 18000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(10) NOT NULL,
  `product_name` varchar(60) NOT NULL,
  `product_image` varchar(300) NOT NULL,
  `product_category` varchar(15) NOT NULL,
  `product_country_origin` varchar(50) NOT NULL,
  `product_place_of_origin` varchar(50) NOT NULL,
  `product_lifespan` varchar(50) NOT NULL,
  `product_color` varchar(70) NOT NULL,
  `product_characteristics` text NOT NULL,
  `number_of_copy` int(11) NOT NULL,
  `product_description` varchar(3000) NOT NULL,
  `product_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_code`, `product_name`, `product_image`, `product_category`, `product_country_origin`, `product_place_of_origin`, `product_lifespan`, `product_color`, `product_characteristics`, `number_of_copy`, `product_description`, `product_price`) VALUES
(1, 'P-00001', 'Minoan Pottery', 'product_image/P-00001_Minoan Pottery.jpg', 'Pottery', 'Greece', 'Athens', '2000-1500 B.C.E', 'Grey', 'There are so many kinds of designs and sizes. Kamares ware, one of the Minoan potteries, is patterned Marine Style and Floral Style. They are thin wall bodies.', 1, 'The pottery consists of vessels of various shapes, which are with other types of Ancient Greece pottery may be collectively referred to as â€œvasesâ€ and also â€œterracottaâ€, small ceramics figurines, models of buildings and some other types. Some pieces, especially the cups of rhythm shape, overlap the two categories, being both vessels for liquids but essentially sculptural objects.', 10000),
(2, 'P-00002', 'Horus Falcon Vissel', 'product_image/P-00002_Horus Falcon Vissel.jpg', 'Pottery', 'Egypt', 'Cairo, Egypt', '3000 BC', 'Many kinds of colors and decorations', 'It has a range of different sizes from 3 inches to 3 feet. The end of the vase comes to a point so it can be stuck into the ground for storage. Horus Falcon Vessels were painted with gold, blue and red decorations. ', 4, 'The Horus Falcon Vessel was made for a functional purpose rather than decorative. It was the most commonly used as a vase. It was named after the first worshipped god in Egypt, Horus. Horus is a god of the sky, war and hunting. Egyptians made pottery before they started building the pyramids. It was made from two types of clay that was from the Nile River, red/brown clay and marl clay.', 12000),
(3, 'P-00003', 'Chinese Porcelain ', 'product_image/P-00003_Chinese Porcelain.jpg', 'Pottery', 'China', 'Beijing', 'Since Han dynasty (260 B.C â€“ 220 B.C)', 'Blue, Grey', 'The color blue gained special significant in the history of Chinese ceramics. It is very beautiful. There are many designs, sizes and colors. They usually use gold or white as the background color.', 3, 'The composition of porcelain is highly variable, but the clay mineral kaolinite is often a raw material. Porcelain will allow bright light to pass through it. The downfall of hard porcelain is despite its strength, its chips fairly easily and is tinged naturally with blue or grey. It is fired at a much higher temperature than soft-paste porcelain and, therefore, it is more difficult and expensive to produce.', 9000),
(4, 'P-00004', 'Mona Lisa ', 'product_image/P-00004_Mona Lisa.jpg', 'Paintings', 'France', 'Paris', '1503â€“1506', '-', '-', 1, 'The Mona Lisa painting was painted by Leonardo Va Vinci in 1503. Mona Lisa, also known as La Gioconda, is the wife of Francesco del Gioconda. This painting is painted as oil on wood. The original size is 77 cm Ã— 53 cm (30 in Ã— 21 in).', 20000),
(5, 'P-00005', 'Villa Della Farnesina, Rome Wall', 'product_image/P-00005_Rome Wall.jpg', 'Paintings', 'Italy', 'Rome, Trastevere', '63 B.C - A.D 14', 'Pompeian red or simply in black', 'The wallpapers were generally painted in Pompeian red or simply in black. The colors were made up of minerals and fine-grained gemstones. It is a painting of the Rome wall with pictures of typical Roman on it. ', 1, 'The painting offers a clean concept of beautification inside an affluent residence throughout the era of Emperor Augustus (63 B.C - A.D 14). The majority of the replicas of lost genuine ones from the ancient Greece, which were originally to be brushed entirely on the wall space in painted frame.', 19000),
(13, 'P-00009', 'Bust of Antinous as Dionysos', '../PresentationLayer/product_image/P-00009_Antinous.jpg', 'Sculptures', 'United kingdon', 'Cambridge', 'AD 130-158', '-', 'It was made from Roman bronze.', 1, 'Around 2000 years ago, a young man of humble Middle Eastern origins died and was worshiped as a God. The man wasnâ€™t Jesus, but Antonius, the companion and the lover of the Rome Emperor Hadrian. Antonius drained in the River Nile when he was 18 years old, leaving Hadrian distraught. Shortly after Antoniusâ€™s death, Hadrian declared that his lover had been reborn as a God, and a cult that lasted for hundreds of years.                                                  ', 12000),
(14, 'P-00010', 'Aung San Su Kyi', '../PresentationLayer/product_image/P-00010_Aung San Su Kyi.jpg', 'Sculptures', 'Norway', 'Oslo', '2012', 'gold, silver, bronze', 'It was casted in bronze in February 2013', 2, 'Aung San Su Kyi is a Burmese politician, diplomat, author, and Nobel Peace Prize laureate (1991).                                                        ', 14000),
(15, 'P-00011', 'Macbeth', '../PresentationLayer/product_image/P-00011_Macbeth.jpg', 'Books', 'Scotland', 'edinburgh', '1623', '-', 'William Shakespare', 2, 'Macbeth, the Thane of Glamis, receives a prophecy from a trio of witches that one day he will become King of Scotland. Consumed by ambition and spurred to action by his wife, Macbeth murders his king and takes the throne for himself', 2500),
(16, 'P-00012', 'Of Mice and Men', '../PresentationLayer/product_image/P-00012_Of mice and men.jpg', 'Books', 'California', 'Soledad', '1937 (Great Depression)', '-', 'John Steinbeck', 2, 'This book was written because John Steinbeck wanted to show how life was during the Great Depression. He wanted to show how people were affected by the depression and what people had to do in order to survive.  Steinbeck based the novella on his own experiences working alongside migrant farm workers as a teenager in the 1910s.  ', 1800),
(17, 'P-00013', 'Cocktail hats', '../PresentationLayer/product_image/P-00013_Cocktail hat.webp', 'Accessories', 'Ergland', 'London', '18005', 'Many Kinds of Colour', 'The cocktail hats are big enough to cover Â¼ of the face.', 2, 'The term fascinator first surfaced in the fashion world in 17th-century Europe. Back then, it referred to a lacy scarf women wrapped around their heads (or "fastened," hence the name). Rather than attracting stares from across the room, this version of the hat was meant to give women an alluring air of mystery. Hats convey social status, style, shade, and warmth.', 2000),
(18, 'P-00014', 'Nassrius Snail Beads', '../PresentationLayer/product_image/P-00014_shell_beads.jpg', 'Jewellery', 'Israel', 'Jerusalem', '110000 years', 'cashnew arts', 'Itâ€™s very pretty. The size of each shells of the sea snail has 1cm.', 1, 'In the site of Skhul cave in Israel, researchers have found beads made from shells of a sea snail called Nassarius. These beads are the first known jewelry made by modern humans dated as early as 110,000 years. Similar beadwork was later found across the African continent, with the oldest examples found in Morocco, dated to some 80,000 years ago. Just a bit younger were the beads found in a cave on the Cape shoreline in south Africa, aging around 75,000 years.', 22000),
(19, 'P-00015', 'Ostrich shell beads of Kenya', '../PresentationLayer/product_image/P-00015_Ostrich-Shell-Beads.jpg', 'Jewellery', 'Kenya', 'Nairobi', '40,000 Years old ', 'cashnew nuts', 'The brown ostrich egg shells look so good tied together on a string.', 1, 'For a long time, it was thought that the oldest personal ornament ever was found in the site of Enkapune Ya Muto, translated as the Twilight Cave, in Kenya. It is believed that they are 40,000 years old. The beads were made from drilled ostrich egg shells tied on a string around the neck. These finds are contemporary to the supposed change in human cognitive abilities, when there was an outburst of imagination and abstract thinking.                            ', 8000),
(20, 'P-00016', 'The Scream', '../PresentationLayer/product_image/P-00016_the-scream.jpg', 'Paintings', 'Norway', 'Oslo', '1893', '-', '-', 2, 'It is The Scream painted by Edvard Munch: Modern and Analysis. In what he referred to as his Soul painting, Edvard Munch reveals an honest and perhaps even ugly glim of his inner troubles and feelings of anxiety, putting more important on personal meaning than on technical skill or beauty, a traditional skill of art.', 15000),
(21, 'P-00017', 'Romeo and Juliet', '../PresentationLayer/product_image/P-00017_Romeo and Juliet.jpg', 'Books', 'Italy', 'Verona', '1595', '-', '-', 7, 'It is wirtten by William Shakespeare. It is wirtten by William Shakespeare. The drama story of Shakespeare is set in Verona, where the two main protagonists, Romeo and Juliet, meet each other and indulge in their love. Both come from two different families, the Capulets and the Montagues, who are sworn enemies. So they decide to keep their love secret and are married by Friar Laurence.                                                                                         ', 19000),
(22, 'P-00018', 'Ladies evening Gloves Opera gloves', '../PresentationLayer/product_image/P-00018_Opera Glooves.jpg', 'Accessories', 'England ', 'London', '1950s', 'Many kinds of colors', 'Opera gloves are between 16 and 22 inches long, though some gloves can be as long as 29 or 30 inches', 2, 'When she wore gloves she could hide her class status, dressing well to elevate herself into a better life. As fashions began to blend the upper and lower classes together, it was in the details of the glove design, material and fit that hinted at status of a woman. Vintage gloves were also a protection from disease.', 1600),
(23, 'P-00019', 'Ancient Rocking Chairs ', '../PresentationLayer/product_image/P-00019_Ancient Rocking Chairs.jpg', 'Furniture', 'England', 'London ', '1725', 'cashew nuts ', 'Originally used in gardens, they were simply ordinary chairs with rockers attached.', 1, 'The rocking chair was initially made as outdoor furniture, but eventually, it found its way into interior design. Initially, the chair was used by elderly people or mothers who were putting their babies to sleep with the help rhythmic motion of the chairs, while simultaneously knitting or doing other activities.', 1500),
(24, 'P-00020', 'Ancient tables', '../PresentationLayer/product_image/P-00020_Ancient table.jpg', 'Furniture', 'Egypt', 'Cairo', '5,000 years old ', 'white', 'Tables were low and usually had four legs, although some had three or even one leg, and were used for games or dining.', 0, 'Most tables were made of wood but some were made of stone or metal. Mehen or game of the snake was played at a one legged table inlaid or carved into the shape of a snake, for example. Other small tables were used for playing games such as senet, or to hold plates of food. Offering tables were often made of stone and sometimes ornately carved. Food for the dead was set upon offering tables-sometimes these were in home shrines, and sometimes they were placed in tombs.', 1700),
(25, 'P-00021', 'French Mahogany Dressing Washstand', '../PresentationLayer/product_image/P-00021_French Mahogany Dressing Washstand.jpg', 'Furniture', 'France', 'Paris ', '1910', 'brown', 'The washstand has a carved mahogany mirror with a Carrera marble top and set of drawers.', 1, 'This lovely french mahogany dressing washstand is offered in very good condition. The washstand retains it is original brass handles and can be used with or without the mirror. The dimensions are 1290mm overall width , 560 mm depth, 2050mm overall height and 1020 height to top of marble', 1800),
(26, 'P-00022', 'Ancient Chandelier ', '../PresentationLayer/product_image/P-00022_Chandelier.jpg', 'Others', 'Austria', 'Wattens', '1965', 'bright colors', 'It is a fixture set at the ceiling which has about two or more arms embracing lights.', 1, 'Chandeliers were originally used in abbeys and medieval churches in order to competently light up huge rooms and halls. Before, chandelier typically form was of a wooden cross which has spikes for securing it. Afterward, chandelier was not only for lighting purposes, it even gained decorative and aesthetic functions, ever since it took on further sophisticated forms. Finding chandeliers in palaces and at the homes of the rich, it that really surprising, in time, chandeliers became a symbol of wealth. ', 2200),
(27, 'P-00023', 'Pocket Watch', '../PresentationLayer/product_image/P-00023_Pocket Watch.jpg', 'Others', 'Germany', 'Nuremberg', '1510', 'cashew nuts color', 'Watches were also mounted on a short leather strap or fob, when a long chain would have been cumbersome or likely to catch on things. This fob could also provide a protective flap over their face and crystal. ', 1, 'A pocket watch  is a watch that is made to be carried in a pocket, as opposed to a wristwatch, which is strapped to the wrist.\r\nThey were the most common type of watch from their development in the 16th century until wristwatches became popular after World War I during which a transitional design, trench watches, were used by the military. Pocket watches generally have an attached chain to allow them to be secured to a waistcoat ,lapel, or belt loop, and to prevent them from being dropped.\r\n', 2300),
(28, 'P-00024', 'Typewriter ', '../PresentationLayer/product_image/P-00024_Typewriter.jpeg', 'Others', 'Wisconsin', 'Milwaukee', '1878', 'cashew nut color', 'Typically, a typewriter has an array of keys, and each one causes a different single character to be produced on the paper, by means of a ribbon with dried ink struck against the paper by a type element similar to the sorts used in movable type letterpress printing.', 1, 'A typewriter is a mechanical or electromechanical machine for writing characters similar to those produced by printers movable type. With older typewriters, a separate type element (called a typebar) corresponds to each key; more recent ones use a single type element (such as a typeball or disc) with a different portion of it used for each character. At the end of the nineteenth century, the term typewriter was also applied to a person who used a typing machine.', 2500),
(29, 'P-00025', 'Glasswork of Egypt', '../PresentationLayer/product_image/P-00025_Glasswork of Egypt.jpg', 'Jewellery', 'Egypt', 'Cairo', '5000 Years', 'Blue', 'Ancient Egyptian glass was rarely used to make large objects and was available only to those of high social status. Glass was instead used to make jewelry such as pendants and beads. Colored glass was used in mosaics, inlaid into furniture, or formed into figurines.', 1, 'The glasses were craved into so many arty shapes and sizes with aesthetic colors on them.', 1500);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product_category`
--

CREATE TABLE `tbl_product_category` (
  `product_category_id` int(100) NOT NULL,
  `product_category_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product_category`
--

INSERT INTO `tbl_product_category` (`product_category_id`, `product_category_name`) VALUES
(1, 'Paintings'),
(2, 'Jewellery'),
(3, 'Accessories'),
(4, 'Pottery'),
(5, 'Sculptures'),
(6, 'Furniture'),
(7, 'Books'),
(8, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_ID` varchar(15) NOT NULL,
  `user_firstname` varchar(50) DEFAULT NULL,
  `user_lastname` varchar(50) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_password` varchar(50) DEFAULT NULL,
  `user_birthday` varchar(30) DEFAULT NULL,
  `user_gender` varchar(7) NOT NULL,
  `user_address` varchar(500) DEFAULT NULL,
  `user_country` varchar(30) DEFAULT NULL,
  `user_phone_number` varchar(30) DEFAULT NULL,
  `member` varchar(15) DEFAULT NULL,
  `register_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_ID`, `user_firstname`, `user_lastname`, `user_email`, `user_password`, `user_birthday`, `user_gender`, `user_address`, `user_country`, `user_phone_number`, `member`, `register_date`) VALUES
('A-00001', 'Hla', 'Yamin Htet', 'admin.antigua@gmail.com', 'admin123', '2000-07-28', 'Female', '400-432 Frederick St, San Francisco, CA 94117, USA', 'American', '424-272-0273', 'admin', '2019-08-16'),
('U-00001', 'Emma', 'Megan', 'emma@gmail.com', '123456', '1960-09-20', 'Famale', 'No.21, Fairfield Street, London', 'England', '+44 20 7123 1234', 'user', '2019-08-16'),
('U-00002', 'Hla Myat', 'Thiri Htet', 'pinky@gmail.com', '050103', '2003-01-05', 'Female', 'A (06-03), Bo Myat Tun Tower, Bo Myat Tun Road, Botahtaung Township, Yangon', 'Myanmar', '09-5011231', 'user', '2019-08-18'),
('U-00003', 'Mg', 'Mg', 'mgmg@gmail.com', '789', '1996-08-17', 'Male', 'No.17, Baho Street, Sanchaung Township, Yangon', 'Myanmar', '09-448012345', 'user', '2019-08-18'),
('U-00004', 'ss', 'ss', 'emma@gmail.com', '1234678', '1999-02-01', 'Male', 'ddd', 'Malaysia', 'ddd', 'user', '2019-10-04'),
('U-00005', 'dd', 'dd', 'admin.antigua@', 'ccccccccc', '1995-02-01', 'Male', 'fff', 'Vitanam', '09-448014750', 'user', '2019-10-04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `productID` (`productID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `tbl_delivery`
--
ALTER TABLE `tbl_delivery`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `tbl_notification`
--
ALTER TABLE `tbl_notification`
  ADD PRIMARY KEY (`noti_id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_product_category`
--
ALTER TABLE `tbl_product_category`
  ADD PRIMARY KEY (`product_category_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_delivery`
--
ALTER TABLE `tbl_delivery`
  MODIFY `delivery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `tbl_notification`
--
ALTER TABLE `tbl_notification`
  MODIFY `noti_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `tbl_product_category`
--
ALTER TABLE `tbl_product_category`
  MODIFY `product_category_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_comment`
--
ALTER TABLE `tbl_comment`
  ADD CONSTRAINT `tbl_comment_ibfk_1` FOREIGN KEY (`productID`) REFERENCES `tbl_product` (`product_id`),
  ADD CONSTRAINT `tbl_comment_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `tbl_user` (`user_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
