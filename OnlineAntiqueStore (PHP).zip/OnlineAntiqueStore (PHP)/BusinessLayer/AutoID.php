<?php 
function AutoID($tableName, $fieldName, $prefix, $noofLeadingZeros){
	$newID = "";
	$sql = "";
	$value = 1;

	$sql = "SELECT " .$fieldName. " FROM " .$tableName. " ORDER BY " .$fieldName. " DESC";

	$result =mysql_query($sql);
	$noofRow =mysql_num_rows($result);
	$row = mysql_fetch_array($result);

	if($noofRow < 1){
		return $prefix."00001";
	}
	else{
		$oldID = $row[$fieldName];
		$oldID = str_replace($prefix, "", $oldID);
		$value = (int)$oldID;
		$value++;
		$newID = $prefix.NumberFormatter($value, $noofLeadingZeros);
		return $newID;
	}
}
function NumberFormatter($number, $n){
	return str_pad((int) $number, $n, "0", STR_PAD_LEFT);
}
 ?>

