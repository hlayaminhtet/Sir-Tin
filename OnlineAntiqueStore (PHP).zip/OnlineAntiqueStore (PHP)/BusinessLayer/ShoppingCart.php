<?php
	//session_start();
	function Insert($ProductCode, $ProductNoOfQty){
		$sql= "SELECT * FROM tbl_product where product_code='$ProductCode'";
		$query =mysql_query($sql);
		$count = mysql_num_rows($query);


		if($count < 1){
			return false;
		}
		$row = mysql_fetch_array($query);

		$ProductCode = $row['product_code'];
		$ProductName = $row['product_name'];
		$ProductImage = $row['product_image'];
		$ProductCategory = $row['product_category'];
		$ProductPrice = $row['product_price'];

		//checking existing quantity
		 $CurrentQty = $row['number_of_copy'];
		// if($ProductNoOfQty > $CurrentQty ){
		// 	echo '<script type="text/javascript">
		// 			alert("Insufficient Quantity!");
		// 			window.="shopping_cartlocation.href.php";
		// 		  	</script>';
		// }
		


			
		if(isset($_SESSION['ShoppingCart']))
		{
			$index=IndexOf($ProductCode);

			if($index == -1)
			{
				$size = count($_SESSION['ShoppingCart']);

				$_SESSION['ShoppingCart'][$size]['ProductCode']=$ProductCode;
				$_SESSION['ShoppingCart'][$size]['ProductName']=$ProductName;
				$_SESSION['ShoppingCart'][$size]['ProductImage']=$ProductImage;
				$_SESSION['ShoppingCart'][$size]['ProductCategory']=$ProductCategory;
				$_SESSION['ShoppingCart'][$size]['ProductPrice']=$ProductPrice;
				$_SESSION['ShoppingCart'][$size]['ProductNoOfQty']= $ProductNoOfQty;
			}
			else
			{
				$_SESSION['ShoppingCart'][$index]['ProductCode']=$ProductCode;
				$_SESSION['ShoppingCart'][$index]['ProductName']=$ProductName;
				$_SESSION['ShoppingCart'][$index]['ProductImage']=$ProductImage;
				$_SESSION['ShoppingCart'][$index]['ProductCategory']=$ProductCategory;
				$_SESSION['ShoppingCart'][$index]['ProductPrice']=$ProductPrice;
				$_SESSION['ShoppingCart'][$index]['ProductNoOfQty']=$_SESSION['ShoppingCart'][$index]['ProductNoOfQty'] + $ProductNoOfQty;

			}
		}
		else{
			$_SESSION['ShoppingCart'] = array();
			$_SESSION['ShoppingCart'][0]['ProductCode']=$ProductCode;
			$_SESSION['ShoppingCart'][0]['ProductName']=$ProductName; 
			$_SESSION['ShoppingCart'][0]['ProductImage']=$ProductImage;
			$_SESSION['ShoppingCart'][0]['ProductCategory']=$ProductCategory;
			$_SESSION['ShoppingCart'][0]['ProductPrice']=$ProductPrice; 
			$_SESSION['ShoppingCart'][0]['ProductNoOfQty']=$ProductNoOfQty;

		
		 }
	}
	function Remove($ProductCode)
	{
		$index=IndexOf($ProductCode);

			if($index > -1)
			{
				unset($_SESSION['ShoppingCart'][$index]);
			}
			$_SESSION['ShoppingCart']=array_values($_SESSION['ShoppingCart']);
	}

	
	function Clear()
	{
		unset($_SESSION['ShoppingCart']);
	}

	function Get_TotalAmount()
	{
		if(!isset($_SESSION['ShoppingCart']))
		{
			return 0;
		}

		$total= 0;
		$size = count($_SESSION['ShoppingCart']);

		for($i=0; $i < $size; $i++){
			$qty= $_SESSION['ShoppingCart'][$i]['ProductNoOfQty'];
			$price =$_SESSION['ShoppingCart'][$i]['ProductPrice'];

			$total = $total + ($qty * $price);
		}
		return $total;
	}

	function IndexOf($ProductCode)
	{
		if(!isset($_SESSION['ShoppingCart']))
			return -1;
		
		$size = count($_SESSION['ShoppingCart']);
		
		if($size == 0)
			return -1;
		
		for($i=0; $i < $size; $i++)
		{
			if($ProductCode == $_SESSION['ShoppingCart'][$i]['ProductCode'])
			{
				return $i;
			}
		}

		return -1;

	}

?>