<?php
	require_once("../DatabaseLayer/db.php");

    //for storing info of user
    require_once("../DatabaseLayer/storeUserInfoControl.php");

    //for retrieving info of user's id
    require_once("../BusinessLayer/AutoID.php");


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome to Antigua</title>
    <link rel="stylesheet" href="bootstrap-3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/fadeup.css">
    <link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora&display=swap" rel="stylesheet">
    <style type="text/css">
    	body{
    		background: #eee;
    	}
    </style>
</head>
<body>
	<div class="signup-form">
    <form action="#" method="post">
    	<!-- Image -->
    	<div class="pos-align">
    		<img src="image/Logo.png" alt="logo" class="logo-responsive">
    	</div>
    	<!-- Heading -->
        <h2 class="text-center">Account Sign Up</h2>     
        <!--  Signup form-->
         <div class="form-group">
           <div class="input-group">
            <div class="input-group-addon">
                <i class="glyphicon glyphicon-ok-sign"></i>
            </div>
            <input type="text" placeholder="" name="txtuserid" class="form-control" value="<?php echo AutoID('tbl_user', 'user_ID','U-', 5);?>" readonly/>
            </div>
        </div>
        <div class="form-group">
            <div class="input-group">
                <!-- <div class="form-inline"> -->
                    <div class="input-group-addon">
                     <i class="glyphicon glyphicon-user"></i>
                    </div>
                    <input type="text" name="txtuserfname" class="form-control" placeholder="First Name" required>
                    <input type="text" name="txtuserlname" class="form-control" placeholder="Last Name" required> 
                <!-- </div> -->
            </div>
        </div>
        <div class="form-group">
           <div class="input-group">
		    <div class="input-group-addon">
		     	<i class="glyphicon glyphicon-envelope"></i>
		    </div>
		    <input type="email" id="txtuseremail" name="txtuseremail" class="form-control" placeholder="Email Address" required>
	    	</div>
        </div>
        <div class="form-group">
            <div class="input-group">
			    <div class="input-group-addon">
			     	<i class="glyphicon glyphicon-lock"></i>
			    </div>
		      	<input type="password" name="txtuserpwd" class="form-control" placeholder="Password" required>
		    </div>
        </div>
        <!-- <div class="form-group">
            <div class="input-group">
                <div class="input-group-addon">
                    <i class="glyphicon glyphicon-check"></i>
                </div>
                <input type="password" name="txtuserconpwd" class="form-control" placeholder="Confirmed Password" required>
            </div>
        </div> -->
        <div class="form-group">
            <div class="input-group">
                <div class="input-group-addon">
                    <i class="glyphicon glyphicon-calendar"></i>
                </div>
                <input type="date" name="txtuserbday" class="form-control" placeholder="Birth of Date" required>
            </div>
        </div>
        <div class="form-group">
            <label class="rdo-title">Gender:</label>
            <div class="input-group">
              <span class="input-group-addon">
                <input type="radio" name="rdousergender" value="Male">
              </span>
              <label class="form-control">Male</label>
            </div>
            <div class="input-group">
              <span class="input-group-addon">
                <input type="radio" name="rdousergender" value="Female">
              </span>
                <label class="form-control">Female</label>
            </div>
            <div id="gender-error-msg" style="display: none;">Please choose on in gender.</div>
        </div>
        <div class="form-group">
            <div class="input-group">
                <div class="input-group-addon">
                    <i class="glyphicon glyphicon-home"></i>
                </div>
                <textarea name="txtuseraddress" class="form-control" placeholder="Address" required></textarea>
            </div>
            <p><span class="star-color">**** </span>Including Home No, Road Name and City</p>
        </div>
        <div class="form-group">
            <div class="input-group">
                <div class="input-group-addon">
                    <i class="glyphicon glyphicon-flag"></i>
                </div>
                  <select class="form-control" name="txtusercountry" required="Please Choose One.">
                    <option style="display:none;">Country:</option>
                    <option>American</option>
                    <option>China</option>
                    <option>England</option>
                    <option>Thailand</option>
                    <option>Laos</option>
                    <option>Myanmar</option>
                    <option>Indonesia</option>
                    <option>Malaysia</option>
                    <option>Philippines</option>
                    <option>Cambodia</option>
                    <option>India</option>
                    <option>Bangladesh</option>
                    <option>Singapore</option>
                    <option>Vitanam</option>
                    <option>Brunei</option>
                    <option>Others</option>
                  </select>
            </div>
        </div> 
        <div class="form-group">
            <div class="input-group">
                <div class="input-group-addon">
                    <i class="glyphicon glyphicon-phone"></i>
                </div>
                <input type="text" name="txtuserph" class="form-control" placeholder="Phone Number" required>
            </div>
        </div>       
        <div class="form-group">
            <button type="submit" id="btnSignup" name="btnSignup" class="btn btn-primary btn-block">Sign Up</button>
        </div>
         <div class="form-group">
            <button type="submit" class="btn btn-primary btn-block"><a href="login.php">Back</a></button>
        </div>
    </form>
    <!-- <p class="text-center"><a href="#">Create an Account</a></p> -->
</div>
</body>
</html>