$( ".dropdown-toggle" ).click(function() {
	$('#manage_product').show();
});
