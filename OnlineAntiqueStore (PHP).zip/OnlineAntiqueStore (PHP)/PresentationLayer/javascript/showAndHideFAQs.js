$(document).ready(function() {
  $(".faq_title").click(function() {
    if ($('.faq_body').is(':visible')) {
      $(".faq_body").slideUp(300);
      $(".plusminus").text('+');
    }
    if ($(this).next(".faq_body").is(':visible')) {
      $(this).next(".faq_body").slideUp(300);
      $(this).children(".plusminus").text('+');
    } else {
      $(this).next(".faq_body").slideDown(300);
      $(this).children(".plusminus").text('=');
    }
  });
});

