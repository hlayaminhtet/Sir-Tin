<?php  
    require_once("../DatabaseLayer/db.php");

    //for retrieving info of Product Category
    require_once("../DatabaseLayer/retrieveProductCategoryControl.php");

     //for retrieving Session user id and information
    require_once("../DatabaseLayer/retrieveUserInfoControl.php");

    //for retrieving notification
    require_once("../DatabaseLayer/retrieveNotificationControl.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome to Antigua</title>
    <link rel="stylesheet" href="bootstrap-3.4.1/css/bootstrap.min.css">
    <!-- For Dropdown list -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/fadeup.css">
    <link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora&display=swap" rel="stylesheet">
</head>
<body>
    <script src="javascript/dropdown.js"></script>
    <!-- header -->
    <div class="header">
        <div class="container">
            <div class="row">
                <!-- logo -->
                <div class="col-md-4">
                    <img src="image/Logo.png" alt="logo" class="logo-responsive">
                </div>
                <!-- search -->
                <div class="col-md-4">
                    <form action="product_searchlist.php" method="POST">
                        <div class="form-group search-pos">
                            <input type="text" name="txtsearch" placeholder="Search..."  style="float: left;">
                            <button class="btn btn-default" name="btnsearch"> 
                                <i class="glyphicon glyphicon-search"></i>
                            </button>  
                        </div>
                    </form>
                </div>
                <!-- process -->
                <div class="col-md-4 process-acc-cart">
                    <!-- notification -->
                    <div class="col-md-4 noti-pos noti-alarm">
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                                <span><img src="image/notification.png" alt="notification"></span>
                                <?php
                                    if($noti_count > 0){
                                ?>
                                <span class="badge badge-notify"><?php echo count($noti_count) ?></span>
                                <?php
                                    }
                                    else{
                                ?>
                                <span class="badge badge-notify"><?php echo "0" ?></span>
                                <?php
                                    }
                                ?>
                            </button>
                            <div class="dropdown-menu notification-layout">
                                <div class="dropdown-item" >
                                <?php
                                    if($noti_count1 > 0){
                                    for($i=0; $i < $noti_count1; $i++){
                                    $noti_row1=mysql_fetch_array($noti_query1);
                                ?>
                                    <div class="notification-body">
                                        <a href="showMessage.php?noti_ID=<?php echo $noti_row1["noti_id"];?>" >
                                            <small>
                                                <?php echo $noti_row1['noti_date']; ?>
                                            </small>
                                            <p><?php echo $noti_row1['noti_username']; ?> (Administrator) sent you a message.</p>
                                        </a>
                                    </div>
                                <?php
                                    }
                                }
                                else{
                                ?>
                                <p>No message yet.</p>
                                <?php
                                    }
                                ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- account -->
                    <div class="col-md-4 pos-align">
                        <div class="dropdown">
                            <div class="dropdown-toggle" type="button" data-toggle="dropdown">
                                <i class="glyphicon glyphicon-user dropdown-toggle"></i>
                                <span>
                                    <label class="account-pos"> <?php echo $user_row["user_firstname"]; ?></label>
                                </span> 
                            </div>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="profile.php" class="dropdown-item">
                                        <i class="glyphicon glyphicon-user"></i><span>Profile</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="settings.php" class="dropdown-item">
                                        <i class="glyphicon glyphicon-cog"></i><span>Settings</span>
                                    </a>
                                </li>
                                <li>
                                    <?php
                                    if($_SESSION['user_ID']=='A-00001')
                                    {
                                    ?>
                                    <a href="manage_product.php" class="dropdown-item">
                                        <i class="glyphicon glyphicon-tasks"></i><span>Manage Products</span>
                                    </a>
                                   <?php
                                    }
                                    else{
                                    ?>
                                    <a href="orderlist.php" class="dropdown-item">
                                        <i class="glyphicon glyphicon-record"></i><span>Order List</span>
                                    </a>
                                    <?php 
                                    }
                                    ?>
                                </li>
                                <li>
                                    <a href="../DatabaseLayer/logOutControl.php" class="dropdown-item">
                                        <i class="glyphicon glyphicon-log-out"></i><span>Log Out</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                     </div>   

                    <!-- shopping cart -->
                    <div class="col-md-4 shopping-process">
                        <a href="shopping_cart.php">
                        <i class="glyphicon glyphicon-shopping-cart"></i>
                        <label>(<?php
                            if (isset($_SESSION['ShoppingCart'])!=0)
                            {
                              echo count($_SESSION['ShoppingCart']);  
                            } 
                            else
                            {
                                echo "0";
                            }

                            ?>)
                          items</label>
                            </a>
                    </div>
                </div>
            
        </div>
    </div>

    <!-- navigation -->
    <div class="navigation pos-align">
        <ul class="list-inline ">
            <li>
                <?php
                    if($_SESSION['user_ID']=='A-00001')
                    {
                ?>
                        <a href="admin_index.php">Home</a>    
                <?php
                    }
                    else{
                ?>                
                        <a href="index.php">Home</a>
                <?php
                    }
                ?>  
            </li>
            <li><a href="about.php">About Us</a></li>
             <li class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Category
                <span class="caret"></span></button>
                <ul class="dropdown-menu">
                    <?php 
                        //for retrieving info of Product Category
                        //retrieveProductCategoryControl.php
                        for($i=0; $i < $product_category_count; $i++){
                        $product_category_row=mysql_fetch_array($product_category_query);
                    ?>
                        <li class="menu-list">
                        <a class="menu-text" href="product_categorylist.php?ProductCategory=<?php echo $product_category_row["product_category_name"];?>">
                        <?php echo $product_category_row["product_category_name"];?> 
                        </a>
                        </li>
                    <?php  
                        }
                    ?>
                </ul>
            </li>
            <li><a href="blog.php">Blog</a></li>
            <li><a href="contact.php">Contact Us</a></li>
        </ul>
    </div>

    <!-- Privacy Policy  -->
    <div class="terms">
        <div class="container">
            <div class="row">
                <h2 class="home-product-title">Terms and Conditions</h2>
                <div class="terms-position">
                    <p>
                        Please read the Terms and Conditions carefully before using Antigua (Online Antique Store).
                    </p>
                    <hr/>
                    <p>
                        &emsp;&emsp;&emsp;To access certain services offered by the platform, we may require that you create an account with us or provide personal information to complete the creation of an account initially. We may at any time in our sole and absolute discretion, invalidate the username and/or password without giving any reason or prior notice and should not be liable or responsible for any losses suffered by, caused by, arising out of, in connection with or by reason of such request or invalidation.
                    </p>
                    <p>
                        &emsp;&emsp;&emsp;You are responsible for maintaining the confidentiality of your user identification, password, account details and related private information. You agree to accept this responsibility and ensure your account and its related details are maintained securely at all times and all necessary steps are taken to prevent misuse of your account. You should inform us immediately if you have any reason to believe that your password has become known to anyone else, or if the password is being, or is likely to be, used in an unauthorized manner. You agree and acknowledge that any use of the site and related services offered and/or any access to private information, data or communications using your account and password should be deemed to be either performed by you or authorized by you as the case may be. You agree to be bound by any access of the site and/or use of any services offered by the site (whether such access or use are authorized by you or not). You agree that we should be entitled (but not obliged) to act upon, rely on or hold you solely responsible and liable in respect thereof as if the same were carried out or transmitted by you. You further agree and acknowledge that you should be bound by and agree to fully indemnify us against any and all losses arising from the use of or access to the site through your account.
                    </p>
                    <p>
                        &emsp;&emsp;&emsp;We may further anonymize data about users of the site generally and use it for various purposes, including ascertaining the general location of the users and usage of certain aspects of the site or a link contained in an email to those registered to receive them, and supplying that anonymized data to third parties such as publishers. However, that anonymized data will not be capable of identifying you personally.
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <!-- Menu -->
                <div class="col-md-3 col-md-offset-1">
                    <h4>Menu</h4>
                    <p><a href="about.php">About Us</a></p>
                    <p><a href="blog.php">Blog</a></p>
                    <p><a href="contact.php">Contact Us</a></p>
                </div>
                <!-- Help -->
                <div class="col-md-3">
                    <h4>Get To Know Us</h4>
                    <p><a href="shippinginfo.php">Shipping Information</a></p>
                    <p><a href="services.php">Services</a></p>
                    <p><a href="terms.php">Terms and Conditions</a></p>
                    <p><a href="policy.php">Privacy Policy</a></p>
                    <p><a href="faqs.php">FAQs</a></p>
                </div>
                <!-- Contact -->
                <div class="col-md-3 col-md-offset-1">
                    <h4>Talk to Us</h4>
                    <i class="glyphicon glyphicon-home"></i>
                    <div class="align-contact">
                        <p>400-432 Frederick St, San Francisco, CA 94117, USA</p>
                    </div>
                    <i class="glyphicon glyphicon-phone-alt"></i>
                    <div class="align-contact">
                        <p>424-272-0273</p>
                    </div>
                    <i class="glyphicon glyphicon-envelope"></i>
                    <div class="align-contact">
                        <p>admin.antigua@gmail.com</p>
                    </div>
                </div>    
            </div>
            <!-- Copyright -->
            <div class="row">
                <div class="copyright">
                    <p class="pos-align">© Copyright 2019 from Antigua Company. All rights reserved.</p>
                </div>
            </div>
            <!-- Social Media -->
            <div class="row">
                <div class="media-align">
                    <a href="https://www.facebook.com/pg/Antigua-Online-Antique-Store-102621827814437/about/?ref=page_internal">
                        <img src="image/facebook_icon1.png" class="img-responsive"/>
                    </a>
                    <a href="https://www.instagram.com/antigua.store/">
                        <img src="image/inshagram_icon.png" class="img-responsive"/>
                    </a>
                    <a href="https://twitter.com/Antigua20865093">
                        <img src="image/twitter_icon.png" class="img-responsive"/>
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>