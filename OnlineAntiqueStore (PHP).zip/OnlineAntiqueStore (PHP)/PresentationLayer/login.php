<?php
	require_once("../DatabaseLayer/db.php");

    //for retrieving info of user's email and password
    require_once("../DatabaseLayer/retrieveEmailandPasswordControl.php");

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome to Antigua</title>
    <link rel="stylesheet" href="bootstrap-3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/fadeup.css">
    <link href="https://fonts.googleapis.com/css?family=Merriweather&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lora&display=swap" rel="stylesheet">
    <style type="text/css">
    	body{
    		background: #eee;
    	}
    </style>
   <!--  <script type="text/javascript" src="javascript/showAndHidePassword.js"></script> -->
    
</head>
<body>
    <!-- <script type="text/javascript" src="javascript/validateEmail.js"></script> -->
	<div class="login-form">
    <form action="#" method="post">
    	<!-- Image -->
    	<div class="pos-align">
    		<img src="image/Logo.png" alt="logo" class="logo-responsive">
    	</div>
    	<!-- Heading -->
        <h2 class="text-center">Account Log in</h2>     
        <!--  Login form-->
        <div class="form-group">
           <div class="input-group">
		    <div class="input-group-addon">
		     	<i class="glyphicon glyphicon-envelope"></i>
		    </div>
		    <input type="email" name="txtuseremail" class="form-control" placeholder="Email Address" required>
	    	</div>
        </div>
        <div class="form-group">
            <div class="input-group">
			    <div class="input-group-addon">
			     	<i class="glyphicon glyphicon-lock"></i>
			    </div>
		      	<input type="password" name="txtuserpwd" id="password" class="form-control" placeholder="Password" required>
		    </div>
        </div>
        <div class="form-group">
            <button type="submit" name="btnLogin" class="btn btn-primary btn-block">Log in</button>
        </div>
    </form>
    <p class="text-center"><a href="signup.php">Create an Account</a></p>
</div>
</body>
</html>